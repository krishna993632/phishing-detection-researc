Vistula phishing-detection experiment evidence

Run: pip install -r requirements.txt; python run_experiment.py
Internet connection required to download UCI dataset 327.
Positive class: phishing (-1 in original dataset). Seeds: 42,13,21,34,55.
Models: Logistic Regression (scaled), Random Forest (200 trees). Conditions: all 30 features, or omit sslfinal_state, url_of_anchor, web_traffic.
Output files: results.csv, confusion_matrices.csv, feature_importance.csv, dataset_audit.txt.
Dataset audit finds 5,270 duplicated feature vectors. Random row splits risk leakage across train/test; results must not be interpreted as independent deployment validation.
Author must rerun and inspect before submission.
