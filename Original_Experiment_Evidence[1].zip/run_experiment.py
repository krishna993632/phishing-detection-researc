"""Reproducible UCI-327 phishing detection experiment.
Requires internet on first run: pip install ucimlrepo pandas scikit-learn numpy
Usage: python run_experiment.py
Output: results.csv, confusion_matrices.csv, feature_importance.csv, dataset_audit.txt
"""
import csv
import sys
from pathlib import Path
import numpy as np
import pandas as pd
from ucimlrepo import fetch_ucirepo
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix

OUT = Path(__file__).resolve().parent
record = fetch_ucirepo(id=327)
X = record.data.features.copy()
y0 = record.data.targets.squeeze()
y = (pd.to_numeric(y0) == -1).astype(int)  # phishing positive class
assert X.shape[1] == 30, X.shape
assert len(X) == 11055, len(X)
assert set(pd.unique(pd.to_numeric(y0))) == {-1, 1}
assert X.isna().sum().sum() == 0
X = X.apply(pd.to_numeric)
print('Downloaded:', X.shape, 'positive=phishing:', int(y.sum()))
print('Feature names:', X.columns.tolist())
with (OUT / 'dataset_audit.txt').open('w') as f:
    f.write(f'Samples: {len(y)}\nFeatures: {X.shape[1]}\nPhishing (-1): {int(y.sum())}\nLegitimate (+1): {int((1-y).sum())}\nMissing feature values: {int(X.isna().sum().sum())}\n')
    f.write(f'Duplicate feature vectors (non-unique rows): {int(X.duplicated().sum())}\n')
    f.write('Feature list:\n' + '\n'.join(map(str,X.columns)))

norm = lambda s: ''.join(ch for ch in s.lower() if ch.isalnum())
remove_keys = {'sslfinalstate', 'urlofanchor', 'webtraffic'}
remove_cols = [c for c in X.columns if norm(c) in remove_keys]
if len(remove_cols) != 3:
    raise RuntimeError('Ablation columns did not resolve as expected: ' + repr(remove_cols))

rows, matrices = [], []
for seed in (42, 13, 21, 34, 55):
    train_idx, test_idx = train_test_split(np.arange(len(y)), test_size=0.2,
                                          random_state=seed, stratify=y)
    for condition, columns in [('all_30', X.columns.tolist()),
                               ('without_three_preselected', [c for c in X.columns if c not in remove_cols])]:
        xtrain, xtest = X.iloc[train_idx][columns], X.iloc[test_idx][columns]
        train_y, test_y = y.iloc[train_idx], y.iloc[test_idx]
        models = {
            'logistic_regression': make_pipeline(StandardScaler(), LogisticRegression(max_iter=2000, random_state=seed)),
            'random_forest': RandomForestClassifier(n_estimators=200, random_state=seed, n_jobs=-1)
        }
        for name, model in models.items():
            model.fit(xtrain, train_y)
            pred = model.predict(xtest)
            tn, fp, fn, tp = confusion_matrix(test_y,pred,labels=[0,1]).ravel()
            rows.append(dict(seed=seed, condition=condition, model=name,
                accuracy=accuracy_score(test_y,pred), precision_phishing=precision_score(test_y,pred,zero_division=0),
                recall_phishing=recall_score(test_y,pred,zero_division=0), f1_phishing=f1_score(test_y,pred,zero_division=0),
                false_negative_phishing=int(fn), false_positive_phishing=int(fp), train_n=len(train_idx), test_n=len(test_idx)))
            matrices.append(dict(seed=seed, condition=condition, model=name,tn=int(tn),fp=int(fp),fn=int(fn),tp=int(tp)))
            if seed == 42 and condition == 'all_30' and name == 'random_forest':
                pd.DataFrame({'feature': columns,'gini_importance': model.feature_importances_}).sort_values('gini_importance',ascending=False).to_csv(OUT/'feature_importance.csv',index=False)
pd.DataFrame(rows).to_csv(OUT/'results.csv',index=False)
pd.DataFrame(matrices).to_csv(OUT/'confusion_matrices.csv',index=False)
print(pd.DataFrame(rows).groupby(['condition','model'])[['accuracy','precision_phishing','recall_phishing','f1_phishing','false_negative_phishing']].agg(['mean','std']).round(4).to_string())
print('Preselected ablated features:', remove_cols)
